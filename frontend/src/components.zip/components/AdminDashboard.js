import React from 'react';
import { Container, Card } from 'react-bootstrap';

function AdminDashboard() {
  return (
    <Container className="mt-5">
      <Card className="card-custom">
        <Card.Body>
          <h2 className="text-center mb-4">Tableau de bord - Administrateur</h2>
          <p>Bienvenue ! Ici, vous pourrez bientôt gérer les utilisateurs et les paramètres de la plateforme.</p>
        </Card.Body>
      </Card>
    </Container>
  );
}

export default AdminDashboard;
