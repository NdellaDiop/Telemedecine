import React from 'react';
import { Container, Row, Col, Button, Card, Form, InputGroup } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSearch, faCalendarCheck, faUserMd, faVideo, faPills, faBell, faPhone, faEnvelope, faMapMarkerAlt } from '@fortawesome/free-solid-svg-icons';
import './HomePage.css';

function HomePage() {
  const navigate = useNavigate();

  return (
    <div className="homepage">
      {/* Header */}
      <header className="bg-white shadow-sm py-3">
        <Container>
          <div className="d-flex justify-content-between align-items-center">
            <a href="/" className="text-decoration-none d-flex align-items-center">
              <img src="/images/logo.png" alt="i-health Logo" height="40" className="me-2" />
              <span className="fw-bold fs-4" style={{ color: '#f5a623' }}>i-health</span>
            </a>

            <div className="d-flex gap-2">
              <Button
                variant="primary"
                className="d-none d-lg-block"
                onClick={() => navigate('/professionnel')}
              >
                VOUS ÊTES PROFESSIONNEL DE SANTÉ ?
              </Button>
              <Button
                variant="outline-primary"
                onClick={() => navigate('/nosmedecin')}
              >
                NOS MEDECIN
              </Button>
              <Button
                variant="outline-primary"
                onClick={() => navigate('/register')} // Nouveau bouton pour s'inscrire
              >
                S’INSCRIRE
              </Button>
              <Button
                variant="outline-warning"
                onClick={() => navigate('/login')}
              >
                SE CONNECTER
              </Button>
            </div>
          </div>
        </Container>
      </header>

      {/* Hero Section with Gradient Background and Doctor Video Call Overlay */}
      <section className="position-relative">
        <div
          className="position-absolute w-100 h-100"
          style={{
            backgroundImage: "url('/images/doctor-call-bg.jpg')",
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            opacity: 0.2,
          }}
        ></div>
        <div
          className="hero-content position-relative py-5"
          style={{
            background: 'linear-gradient(135deg, rgba(0,123,255,0.9) 0%, rgba(40,167,69,0.9) 100%)',
            color: 'white',
          }}
        >
          <Container className="py-4 text-center">
            <h1 className="display-4 mb-3">Chercher Médecin, Prendre Rendez-vous</h1>
            <p className="lead mb-4">
              Découvrez les meilleurs médecins, cliniques et hôpitaux de la ville la plus proche de chez vous.
            </p>

            <Row className="justify-content-center">
              <Col md={10} lg={8}>
                <InputGroup className="mb-3 shadow">
                  <Form.Control
                    placeholder="Votre localisation"
                    defaultValue="Sénégal"
                    className="py-3"
                  />
                  <Form.Control
                    placeholder="Spécialité, nom du médecin..."
                    className="border-start-0 border-end-0 py-3"
                  />
                  <Button
                    variant="success"
                    className="px-4"
                    onClick={() => alert('Recherche de médecins lancée !')}
                  >
                    <FontAwesomeIcon icon={faSearch} className="me-2" /> Rechercher
                  </Button>
                </InputGroup>
              </Col>
            </Row>
          </Container>
        </div>
      </section>

      {/* Video Call Section */}
      <section className="bg-light py-5">
        <Container>
          <Row className="align-items-center">
            <Col lg={6} className="mb-4 mb-lg-0">
              <h2 className="fw-bold mb-3">Consultez votre médecin en ligne</h2>
              <p className="lead mb-4">
                Accédez à des consultations médicales par vidéo depuis le confort de votre domicile.
                Recevez des diagnostics, des ordonnances et des conseils médicaux sans vous déplacer.
              </p>
              <Button
                variant="primary"
                size="lg"
                onClick={() => navigate('/teleconsultation')}
              >
                <FontAwesomeIcon icon={faVideo} className="me-2" />
                Découvrir la téléconsultation
              </Button>
            </Col>
            <Col lg={6}>
              <div className="rounded overflow-hidden shadow">
                <img
                  src="/images/doctor-video-call.jpg"
                  alt="Consultation vidéo avec un médecin"
                  className="img-fluid w-100"
                />
              </div>
            </Col>
          </Row>
        </Container>
      </section>

      {/* Features Section */}
      <section className="py-5">
        <Container>
          <div className="text-center mb-5">
            <h2 className="fw-bold mb-3">Nos services</h2>
            <p className="lead text-muted">
              Découvrez comment i-health peut vous aider à gérer votre santé plus facilement
            </p>
          </div>

          <Row>
            <Col md={6} lg={4} className="mb-4">
              <Card className="h-100 shadow-sm border-0 transition-hover">
                <Card.Body className="text-center p-4">
                  <div className="mb-3 text-primary">
                    <FontAwesomeIcon icon={faSearch} size="2x" />
                  </div>
                  <h3 className="h5 mb-3">Recherche de médecins</h3>
                  <p className="text-muted mb-0">
                    Trouvez facilement des médecins par spécialité, localisation ou nom selon vos besoins spécifiques.
                  </p>
                </Card.Body>
              </Card>
            </Col>

            <Col md={6} lg={4} className="mb-4">
              <Card className="h-100 shadow-sm border-0 transition-hover">
                <Card.Body className="text-center p-4">
                  <div className="mb-3 text-primary">
                    <FontAwesomeIcon icon={faCalendarCheck} size="2x" />
                  </div>
                  <h3 className="h5 mb-3">Prise de rendez-vous</h3>
                  <p className="text-muted mb-0">
                    Prenez rendez-vous en ligne rapidement et recevez une confirmation instantanée par email.
                  </p>
                </Card.Body>
              </Card>
            </Col>

            <Col md={6} lg={4} className="mb-4">
              <Card className="h-100 shadow-sm border-0 transition-hover">
                <Card.Body className="text-center p-4">
                  <div className="mb-3 text-primary">
                    <FontAwesomeIcon icon={faUserMd} size="2x" />
                  </div>
                  <h3 className="h5 mb-3">Dossier médical</h3>
                  <p className="text-muted mb-0">
                    Accédez à votre dossier médical en ligne et consultez votre historique médical en toute sécurité.
                  </p>
                </Card.Body>
              </Card>
            </Col>

            <Col md={6} lg={4} className="mb-4">
              <Card className="h-100 shadow-sm border-0 transition-hover">
                <Card.Body className="text-center p-4">
                  <div className="mb-3 text-primary">
                    <FontAwesomeIcon icon={faVideo} size="2x" />
                  </div>
                  <h3 className="h5 mb-3">Téléconsultation</h3>
                  <p className="text-muted mb-0">
                    Consultez des médecins par vidéo et recevez des soins médicaux depuis votre domicile.
                  </p>
                </Card.Body>
              </Card>
            </Col>

            <Col md={6} lg={4} className="mb-4">
              <Card className="h-100 shadow-sm border-0 transition-hover">
                <Card.Body className="text-center p-4">
                  <div className="mb-3 text-primary">
                    <FontAwesomeIcon icon={faPills} size="2x" />
                  </div>
                  <h3 className="h5 mb-3">Ordonnances en ligne</h3>
                  <p className="text-muted mb-0">
                    Recevez vos ordonnances électroniques directement après votre consultation.
                  </p>
                </Card.Body>
              </Card>
            </Col>

            <Col md={6} lg={4} className="mb-4">
              <Card className="h-100 shadow-sm border-0 transition-hover">
                <Card.Body className="text-center p-4">
                  <div className="mb-3 text-primary">
                    <FontAwesomeIcon icon={faBell} size="2x" />
                  </div>
                  <h3 className="h5 mb-3">Rappels et notifications</h3>
                  <p className="text-muted mb-0">
                    Recevez des rappels pour vos rendez-vous et des notifications pour vos traitements.
                  </p>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Container>
      </section>

      {/* Footer */}
      <footer className="bg-dark text-white py-5">
        <Container>
          <Row>
            <Col lg={3} md={6} className="mb-4 mb-lg-0">
              <h5 className="text-warning mb-3">i-health</h5>
              <ul className="list-unstyled">
                <li className="mb-2"><a href="#" className="text-decoration-none text-light">À propos de nous</a></li>
                <li className="mb-2"><a href="#" className="text-decoration-none text-light">Nos services</a></li>
                <li className="mb-2"><a href="#" className="text-decoration-none text-light">Carrières</a></li>
                <li className="mb-2"><a href="#" className="text-decoration-none text-light">Blog</a></li>
              </ul>
            </Col>

            <Col lg={3} md={6} className="mb-4 mb-lg-0">
              <h5 className="text-warning mb-3">Pour les patients</h5>
              <ul className="list-unstyled">
                <li className="mb-2"><a href="#" className="text-decoration-none text-light">Rechercher un médecin</a></li>
                <li className="mb-2"><a href="#" className="text-decoration-none text-light">Prendre rendez-vous</a></li>
                <li className="mb-2"><a href="#" className="text-decoration-none text-light">Consulter mon dossier</a></li>
                <li className="mb-2"><a href="#" className="text-decoration-none text-light">FAQ</a></li>
              </ul>
            </Col>

            <Col lg={3} md={6} className="mb-4 mb-lg-0">
              <h5 className="text-warning mb-3">Pour les médecins</h5>
              <ul className="list-unstyled">
                <li className="mb-2"><a href="#" className="text-decoration-none text-light">Rejoindre i-health</a></li>
                <li className="mb-2"><a href="#" className="text-decoration-none text-light">Gérer votre agenda</a></li>
                <li className="mb-2"><a href="#" className="text-decoration-none text-light">Nos solutions</a></li>
                <li className="mb-2"><a href="#" className="text-decoration-none text-light">Support</a></li>
              </ul>
            </Col>

            <Col lg={3} md={6}>
              <h5 className="text-warning mb-3">Contact</h5>
              <ul className="list-unstyled">
                <li className="mb-2">
                  <a href="tel:338888888" className="text-decoration-none text-light">
                    <FontAwesomeIcon icon={faPhone} className="me-2" /> 33 888 88 88
                  </a>
                </li>
                <li className="mb-2">
                  <a href="mailto:contact@i-health.com" className="text-decoration-none text-light">
                    <FontAwesomeIcon icon={faEnvelope} className="me-2" /> contact@i-health.com
                  </a>
                </li>
                <li className="mb-2">
                  <a href="#" className="text-decoration-none text-light">
                    <FontAwesomeIcon icon={faMapMarkerAlt} className="me-2" /> Dakar, Sénégal
                  </a>
                </li>
              </ul>
            </Col>
          </Row>

          <div className="text-center pt-4 mt-4 border-top border-secondary">
            <p className="text-muted mb-0">© 2025 i-health. Tous droits réservés.</p>
          </div>
        </Container>
      </footer>
    </div>
  );
}

export default HomePage;
