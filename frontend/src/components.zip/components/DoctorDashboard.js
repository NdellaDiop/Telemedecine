import React, { useState } from 'react';
import { User, Calendar, FileText, Video, MessageCircle, LogOut, Image, Settings, ChevronLeft, Search, Clock } from 'lucide-react';

// Mock data - in a real application, this would come from backend API
const mockPatientData = {
  name: 'Jean Dupont',
  type: 'Patient',
  upcomingAppointments: [
    { 
      date: '2024-05-15', 
      time: '09:00', 
      type: 'Téléconsultation', 
      doctor: 'Dr. Martin',
      status: 'Confirmé'
    },
    { 
      date: '2024-05-15', 
      time: '10:30', 
      type: 'Consultation', 
      doctor: 'Dr. Bernard',
      status: 'En attente'
    },
    { 
      date: '2024-05-15', 
      time: '14:15', 
      type: 'Téléconsultation', 
      doctor: 'Dr. Petit',
      status: 'Confirmé'
    }
  ],
  summaryStats: {
    consultations: 5,
    teleconsultations: 3
  },
  medicalRecords: [
    { 
      type: 'Ordonnance', 
      date: '2023-06-20', 
      details: 'Prescription de suivi' 
    },
    { 
      type: 'Résultats d\'analyse', 
      date: '2023-05-10', 
      details: 'Analyse sanguine' 
    }
  ]
};

// Orthanc integration component for medical imaging
const OrthancViewer = () => {
  const [images, setImages] = useState([]);

  const fetchOrthancImages = async () => {
    // In a real implementation, this would call Orthanc API
    try {
      // Placeholder for Orthanc image fetching logic
      const mockImages = [
        { id: '1', url: '/api/placeholder/200/200', description: 'Radiographie' },
        { id: '2', url: '/api/placeholder/200/200', description: 'Scanner' }
      ];
      setImages(mockImages);
    } catch (error) {
      console.error('Erreur de récupération des images', error);
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold">Mes Examens Médicaux</h2>
        <button 
          onClick={fetchOrthancImages} 
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
        >
          Charger les images
        </button>
      </div>
      <div className="grid grid-cols-2 gap-4">
        {images.map(image => (
          <div key={image.id} className="border rounded p-2">
            <img 
              src={image.url} 
              alt={image.description} 
              className="w-full h-40 object-cover"
            />
            <p className="text-center mt-2">{image.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

// Main Patient Dashboard Component
const PatientDashboard = () => {
  const [activeSection, setActiveSection] = useState('dashboard');

  const renderDashboardContent = () => {
    switch(activeSection) {
      case 'dashboard':
        return (
          <div className="space-y-6">
            {/* Summary Stats */}
            <div className="flex flex-wrap gap-4">
              <div className="bg-blue-100 p-6 rounded-lg shadow-sm flex-1">
                <h3 className="text-lg font-medium mb-2">Consultations</h3>
                <span className="text-4xl font-bold">{mockPatientData.summaryStats.consultations}</span>
              </div>
              <div className="bg-purple-100 p-6 rounded-lg shadow-sm flex-1">
                <h3 className="text-lg font-medium mb-2">Téléconsultations</h3>
                <span className="text-4xl font-bold">{mockPatientData.summaryStats.teleconsultations}</span>
              </div>
            </div>
            
            {/* Upcoming Appointments */}
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold">Prochains rendez-vous</h2>
                <button className="text-blue-500 hover:underline">Voir tous</button>
              </div>
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left pb-3">Médecin</th>
                    <th className="text-left pb-3">Heure</th>
                    <th className="text-left pb-3">Type</th>
                    <th className="text-left pb-3">Statut</th>
                    <th className="text-right pb-3">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {mockPatientData.upcomingAppointments.map((appt, index) => (
                    <tr key={index} className="border-b">
                      <td className="py-3">{appt.doctor}</td>
                      <td className="py-3">{appt.time}</td>
                      <td className="py-3">
                        <span className={`px-3 py-1 rounded-full text-sm ${appt.type === 'Téléconsultation' ? 'bg-purple-100 text-purple-800' : 'bg-blue-100 text-blue-800'}`}>
                          {appt.type}
                        </span>
                      </td>
                      <td className="py-3">
                        <span className={`px-3 py-1 rounded-full text-sm ${appt.status === 'Confirmé' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
                          {appt.status}
                        </span>
                      </td>
                      <td className="py-3 text-right">
                        <button className="text-gray-500 hover:text-blue-500 mr-2">
                          <FileText size={18} />
                        </button>
                        {appt.type === 'Téléconsultation' && (
                          <button className="text-gray-500 hover:text-purple-500">
                            <Video size={18} />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <button className="mt-6 bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">
                Nouveau Rendez-vous
              </button>
            </div>
          </div>
        );
      case 'teleconsultation':
        return (
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <h2 className="text-xl font-semibold mb-6">Téléconsultation</h2>
            <div className="mb-6">
              <p className="text-gray-600 mb-4">Vos prochaines téléconsultations:</p>
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left pb-3">Médecin</th>
                    <th className="text-left pb-3">Date</th>
                    <th className="text-left pb-3">Heure</th>
                    <th className="text-left pb-3">Statut</th>
                    <th className="text-right pb-3">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {mockPatientData.upcomingAppointments
                    .filter(appt => appt.type === 'Téléconsultation')
                    .map((appt, index) => (
                      <tr key={index} className="border-b">
                        <td className="py-3">{appt.doctor}</td>
                        <td className="py-3">{appt.date}</td>
                        <td className="py-3">{appt.time}</td>
                        <td className="py-3">
                          <span className={`px-3 py-1 rounded-full text-sm ${appt.status === 'Confirmé' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
                            {appt.status}
                          </span>
                        </td>
                        <td className="py-3 text-right">
                          <button className="bg-purple-500 text-white px-3 py-1 rounded hover:bg-purple-600">
                            Rejoindre
                          </button>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
            <button className="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600">
              Programmer une nouvelle téléconsultation
            </button>
          </div>
        );
      case 'medical-records':
        return (
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <h2 className="text-xl font-semibold mb-6">Mon Dossier Médical</h2>
            <div className="mb-6">
              <div className="mb-4">
                <h3 className="text-lg font-medium mb-2">Informations personnelles</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-gray-600">Nom:</p>
                    <p className="font-medium">{mockPatientData.name}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Type:</p>
                    <p className="font-medium">{mockPatientData.type}</p>
                  </div>
                </div>
              </div>
              <div>
                <h3 className="text-lg font-medium mb-2">Documents médicaux</h3>
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left pb-3">Type</th>
                      <th className="text-left pb-3">Date</th>
                      <th className="text-left pb-3">Détails</th>
                      <th className="text-right pb-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mockPatientData.medicalRecords.map((record, index) => (
                      <tr key={index} className="border-b">
                        <td className="py-3">{record.type}</td>
                        <td className="py-3">{record.date}</td>
                        <td className="py-3">{record.details}</td>
                        <td className="py-3 text-right">
                          <button className="text-blue-500 hover:underline">Voir</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
            <button className="mt-4 bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
              Ajouter un document
            </button>
          </div>
        );
      case 'orthanc':
        return <OrthancViewer />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen flex">
      {/* Sidebar */}
      <div className="w-64 bg-white border-r shadow-sm">
        <div className="p-4 border-b bg-blue-500 text-white">
          <h1 className="text-xl font-bold mb-1">MediConnect</h1>
          <p className="text-sm">Plateforme de Télémédecine</p>
        </div>
        
        <div className="p-4 border-b flex items-center">
          <User className="mr-3 text-blue-500" size={32} />
          <div>
            <p className="font-medium">{mockPatientData.name}</p>
            <p className="text-sm text-gray-600">{mockPatientData.type}</p>
          </div>
        </div>
        
        <nav className="p-2">
          <button 
            onClick={() => setActiveSection('dashboard')}
            className={`w-full flex items-center p-3 mb-1 rounded text-left ${activeSection === 'dashboard' ? 'bg-blue-100 text-blue-600' : 'hover:bg-gray-100'}`}
          >
            <Calendar className="mr-3" />
            <span>Agenda</span>
          </button>
          <button 
            onClick={() => setActiveSection('medical-records')}
            className={`w-full flex items-center p-3 mb-1 rounded text-left ${activeSection === 'medical-records' ? 'bg-blue-100 text-blue-600' : 'hover:bg-gray-100'}`}
          >
            <FileText className="mr-3" />
            <span>Dossier Médical</span>
          </button>
          <button 
            onClick={() => setActiveSection('teleconsultation')}
            className={`w-full flex items-center p-3 mb-1 rounded text-left ${activeSection === 'teleconsultation' ? 'bg-blue-100 text-blue-600' : 'hover:bg-gray-100'}`}
          >
            <Video className="mr-3" />
            <span>Téléconsultation</span>
          </button>
          <button 
            className={`w-full flex items-center p-3 mb-1 rounded text-left hover:bg-gray-100`}
          >
            <MessageCircle className="mr-3" />
            <span>Messages</span>
            <span className="ml-auto bg-red-500 text-white text-xs px-2 py-1 rounded-full">2</span>
          </button>
          <button 
            onClick={() => setActiveSection('orthanc')}
            className={`w-full flex items-center p-3 mb-1 rounded text-left ${activeSection === 'orthanc' ? 'bg-blue-100 text-blue-600' : 'hover:bg-gray-100'}`}
          >
            <Image className="mr-3" />
            <span>Orthanc - Imagerie</span>
          </button>
        </nav>
        
        <div className="mt-auto p-2 border-t">
          <button className={`w-full flex items-center p-3 mb-1 rounded text-left hover:bg-gray-100`}>
            <Settings className="mr-3" />
            <span>Paramètres</span>
          </button>
          <button className={`w-full flex items-center p-3 mb-1 rounded text-left hover:bg-gray-100`}>
            <LogOut className="mr-3" />
            <span>Déconnexion</span>
          </button>
        </div>
      </div>
      
      {/* Main Content */}
      <div className="flex-1 bg-gray-100">
        {/* Header */}
        <header className="bg-white p-4 flex justify-between items-center shadow-sm">
          <div className="flex items-center">
            <button className="mr-4">
              <ChevronLeft />
            </button>
            <h1 className="text-2xl font-bold">Mon Agenda</h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="relative">
              <input 
                type="text" 
                placeholder="Rechercher..." 
                className="pl-10 pr-4 py-2 border rounded-lg"
              />
              <Search className="absolute left-3 top-2.5 text-gray-400" size={18} />
            </div>
            <button className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 flex items-center">
              <Clock className="mr-2" size={18} />
              Disponibilité
            </button>
          </div>
        </header>
        
        {/* Main Content Area */}
        <div className="p-6">
          {renderDashboardContent()}
        </div>
      </div>
    </div>
  );
};

export default PatientDashboard;