import React from 'react';
import { Navbar, Nav, Container } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

function CustomNavbar() {
  const navigate = useNavigate();

  return (
    <Navbar className="navbar-custom" expand="lg" fixed="top">
      <Container>
        <Navbar.Brand href="/" style={{ color: 'white', fontWeight: 'bold' }}>
          Télémédecine Sénégal
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="ms-auto">
            <Nav.Link onClick={() => navigate('/')}>Accueil</Nav.Link>
            <Nav.Link onClick={() => navigate('/register')}>S'inscrire</Nav.Link>
            <Nav.Link onClick={() => navigate('/login')}>Se connecter</Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default CustomNavbar;
