import React, { useState } from 'react';
import { Container, Row, Col, Card, Button, Nav, Tab, Table, Badge, Form, InputGroup } from 'react-bootstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faCalendarCheck, faUserMd, faFileMedical, faVideo, faPills,
  faBell, faComments, faChartLine, faSearch, faDownload, faUserCircle, faPhone
} from '@fortawesome/free-solid-svg-icons';
import {
  LineChart, Line, XAxis, YAxis, Tooltip, Legend, BarChart, Bar,
  AreaChart, Area, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar
} from 'recharts';
import './PatientDashboard.css';

function PatientDashboard() {
  // Patient data state
  const [patient, setPatient] = useState({
    name: 'Ndeye Ndella Diop',
    age: 23,
    address: 'Dakar, Sénégal',
    phone: '77 805 00 26',
    email: 'ndeyendelladiop@esp.sn',
    profileImage: '/images/patient-avatar.jpg',
  });

  // Upcoming appointments state
  const [upcomingAppointments, setUpcomingAppointments] = useState([
    {
      id: 'RDV123',
      doctor: 'Dr. Aissata Sy',
      specialty: 'Cardiologie',
      date: '10 Mai 2025',
      time: '14:30',
      type: 'Téléconsultation',
      status: 'confirmé',
    },
    {
      id: 'RDV124',
      doctor: 'Dr. Ndeye Ndella Diop',
      specialty: 'Médecine Générale',
      date: '15 Mai 2025',
      time: '09:00',
      type: 'Présentiel',
      status: 'en attente',
    },
  ]);

  // Appointment history state
  const [appointmentHistory, setAppointmentHistory] = useState([
    {
      id: 'RDV100',
      doctor: 'Dr. Ndeye Daba Seck',
      specialty: 'Dermatologie',
      date: '25 Avril 2025',
      time: '10:15',
      type: 'Téléconsultation',
      status: 'terminé',
    },
    {
      id: 'RDV090',
      doctor: 'Dr. Aissata Sy',
      specialty: 'Cardiologie',
      date: '10 Avril 2025',
      time: '11:30',
      type: 'Présentiel',
      status: 'terminé',
    },
  ]);

  // Prescriptions state
  const [prescriptions, setPrescriptions] = useState([
    {
      id: 'ORD123',
      doctor: 'Dr. Aissata Sy',
      date: '10 Avril 2025',
      medications: [
        { name: 'Paracétamol', dosage: '1000mg', frequency: '3x par jour', duration: '5 jours' },
        { name: 'Amoxicilline', dosage: '500mg', frequency: '2x par jour', duration: '7 jours' },
      ],
      status: 'actif',
    },
    {
      id: 'ORD110',
      doctor: 'Dr. Ndeye Daba Seck',
      date: '25 Mars 2025',
      medications: [{ name: 'Loratadine', dosage: '10mg', frequency: '1x par jour', duration: '15 jours' }],
      status: 'expiré',
    },
  ]);

  // Placeholder chart data
  const bloodPressureData = [
    { date: '01/05', systolic: 120, diastolic: 80 },
    { date: '02/05', systolic: 122, diastolic: 82 },
    { date: '03/05', systolic: 118, diastolic: 78 },
    { date: '04/05', systolic: 124, diastolic: 84 },
  ];

  const weightData = [
    { date: '01/05', weight: 65 },
    { date: '02/05', weight: 64.5 },
    { date: '03/05', weight: 65.2 },
    { date: '04/05', weight: 64.8 },
  ];

  const heartRateData = [
    { date: '01/05', heartRate: 72 },
    { date: '02/05', heartRate: 70 },
    { date: '03/05', heartRate: 74 },
    { date: '04/05', heartRate: 71 },
  ];

  const bloodSugarData = [
    { date: '01/05', bloodSugar: 90 },
    { date: '02/05', bloodSugar: 88 },
    { date: '03/05', bloodSugar: 92 },
    { date: '04/05', bloodSugar: 89 },
  ];

  const healthData = [
    {
      date: '01/05/2025',
      bloodPressure: { systolic: 120, diastolic: 80 },
      weight: 65,
      heartRate: 72,
      bloodSugar: 90,
    },
    {
      date: '02/05/2025',
      bloodPressure: { systolic: 122, diastolic: 82 },
      weight: 64.5,
      heartRate: 70,
      bloodSugar: 88,
    },
  ];

  // Function to format status with a badge
  const getStatusBadge = (status) => {
    switch (status) {
      case 'confirmé':
        return <Badge bg="success">Confirmé</Badge>;
      case 'en attente':
        return <Badge bg="warning">En attente</Badge>;
      case 'terminé':
        return <Badge bg="info">Terminé</Badge>;
      case 'actif':
        return <Badge bg="success">Actif</Badge>;
      case 'expiré':
        return <Badge bg="secondary">Expiré</Badge>;
      default:
        return <Badge bg="primary">{status}</Badge>;
    }
  };

  return (
    <div className="patient-dashboard bg-light">
      {/* Header with patient information */}
      <header className="bg-primary text-white py-4 mb-4">
        <Container>
          <Row className="align-items-center">
            <Col md={2} className="text-center mb-3 mb-md-0">
              <div className="avatar-container">
                {patient.profileImage ? (
                  <img
                    src={patient.profileImage}
                    alt="Profile"
                    className="avatar rounded-circle border border-3 border-white shadow"
                  />
                ) : (
                  <FontAwesomeIcon icon={faUserCircle} size="5x" />
                )}
              </div>
            </Col>
            <Col md={6}>
              <h2 className="mb-1">{patient.name}</h2>
              <p className="mb-1">ID: {patient.id} | Âge: {patient.age} ans | Groupe sanguin: {patient.bloodType}</p>
              <p className="mb-0">{patient.address} | {patient.phone}</p>
            </Col>
            <Col md={4} className="d-flex justify-content-md-end mt-3 mt-md-0">
              <Button variant="light" className="me-2">
                <FontAwesomeIcon icon={faFileMedical} className="me-2" />
                Mon dossier complet
              </Button>
              <Button variant="warning">
                <FontAwesomeIcon icon={faBell} className="me-2" />
                Notifications
              </Button>
            </Col>
          </Row>
        </Container>
      </header>

      <Container>
        {/* Key data overview */}
        <Row className="mb-4">
          <Col md={3} className="mb-3 mb-md-0">
            <Card className="h-100 shadow-sm">
              <Card.Body className="text-center">
                <div className="display-4 text-primary mb-2">{upcomingAppointments.length}</div>
                <Card.Title className="fs-6 text-muted">Rendez-vous à venir</Card.Title>
              </Card.Body>
            </Card>
          </Col>
          <Col md={3} className="mb-3 mb-md-0">
            <Card className="h-100 shadow-sm">
              <Card.Body className="text-center">
                <div className="display-4 text-success mb-2">{prescriptions.filter((p) => p.status === 'actif').length}</div>
                <Card.Title className="fs-6 text-muted">Ordonnances actives</Card.Title>
              </Card.Body>
            </Card>
          </Col>
          <Col md={3} className="mb-3 mb-md-0">
            <Card className="h-100 shadow-sm">
              <Card.Body className="text-center">
                <div className="display-4 text-info mb-2">{appointmentHistory.length}</div>
                <Card.Title className="fs-6 text-muted">Consultations passées</Card.Title>
              </Card.Body>
            </Card>
          </Col>
          <Col md={3} className="mb-3 mb-md-0">
            <Card className="h-100 shadow-sm">
              <Card.Body className="text-center">
                <div className="display-4 text-warning mb-2">3</div>
                <Card.Title className="fs-6 text-muted">Médecins consultés</Card.Title>
              </Card.Body>
            </Card>
          </Col>
        </Row>

        {/* Quick actions */}
        <Row className="mb-4">
          <Col>
            <Card className="shadow-sm">
              <Card.Body>
                <h5 className="mb-3">Actions rapides</h5>
                <div className="d-flex flex-wrap gap-2">
                  <Button variant="primary">
                    <FontAwesomeIcon icon={faCalendarCheck} className="me-2" />
                    Prendre RDV 
                  </Button>
                  <Button variant="success">
                    <FontAwesomeIcon icon={faVideo} className="me-2" />
                    Démarrer une téléconsultation
                  </Button>
                  <Button variant="info" className="text-white">
                    <FontAwesomeIcon icon={faUserMd} className="me-2" />
                    Consulter un médecin
                  </Button>
                  <Button variant="secondary">
                    <FontAwesomeIcon icon={faFileMedical} className="me-2" />
                    Ajouter un document
                  </Button>
                  <Button variant="warning">
                    <FontAwesomeIcon icon={faComments} className="me-2" />
                    Messages
                  </Button>
                </div>
              </Card.Body>
            </Card>
          </Col>
        </Row>

        {/* Main content */}
        <Tab.Container id="dashboard-tabs" defaultActiveKey="appointments">
          <Row>
            <Col md={3} className="mb-4">
              <Card className="shadow-sm">
                <Card.Body className="p-0">
                  <Nav variant="pills" className="flex-column dashboard-nav">
                    <Nav.Item>
                      <Nav.Link eventKey="appointments" className="rounded-0 border-bottom">
                        <FontAwesomeIcon icon={faCalendarCheck} className="me-2" />
                        Mes rendez-vous
                      </Nav.Link>
                    </Nav.Item>
                    <Nav.Item>
                      <Nav.Link eventKey="medical-records" className="rounded-0 border-bottom">
                        <FontAwesomeIcon icon={faFileMedical} className="me-2" />
                        Dossier médical
                      </Nav.Link>
                    </Nav.Item>
                    <Nav.Item>
                      <Nav.Link eventKey="prescriptions" className="rounded-0 border-bottom">
                        <FontAwesomeIcon icon={faPills} className="me-2" />
                        Mes ordonnances
                      </Nav.Link>
                    </Nav.Item>
                    <Nav.Item>
                      <Nav.Link eventKey="teleconsultation" className="rounded-0 border-bottom">
                        <FontAwesomeIcon icon={faVideo} className="me-2" />
                        Téléconsultation
                      </Nav.Link>
                    </Nav.Item>
                    <Nav.Item>
                      <Nav.Link eventKey="messages" className="rounded-0 border-bottom">
                        <FontAwesomeIcon icon={faComments} className="me-2" />
                        Messages
                      </Nav.Link>
                    </Nav.Item>
                    <Nav.Item>
                      <Nav.Link eventKey="health-tracking" className="rounded-0">
                        <FontAwesomeIcon icon={faChartLine} className="me-2" />
                        Suivi de santé
                      </Nav.Link>
                    </Nav.Item>
                  </Nav>
                </Card.Body>
              </Card>
            </Col>

            <Col md={9}>
              <Card className="shadow-sm">
                <Card.Body>
                  <Tab.Content>
                    {/* Appointments Tab */}
                    <Tab.Pane eventKey="appointments">
                      <div className="d-flex justify-content-between align-items-center mb-4">
                        <h4 className="mb-0">Mes rendez-vous</h4>
                        <Button variant="outline-primary">
                          <FontAwesomeIcon icon={faCalendarCheck} className="me-2" />
                          Nouveau rendez-vous
                        </Button>
                      </div>

                      <h5 className="mb-3">Rendez-vous à venir</h5>
                      <Table responsive hover className="mb-4">
                        <thead className="bg-light">
                          <tr>
                            <th>Médecin</th>
                            <th>Spécialité</th>
                            <th>Date</th>
                            <th>Heure</th>
                            <th>Type</th>
                            <th>Statut</th>
                            <th>Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {upcomingAppointments.map((appointment) => (
                            <tr key={appointment.id}>
                              <td>{appointment.doctor}</td>
                              <td>{appointment.specialty}</td>
                              <td>{appointment.date}</td>
                              <td>{appointment.time}</td>
                              <td>{appointment.type}</td>
                              <td>{getStatusBadge(appointment.status)}</td>
                              <td>
                                <div className="d-flex gap-1">
                                  <Button variant="outline-primary" size="sm">
                                    Détails
                                  </Button>
                                  {appointment.status === 'confirmé' && appointment.type === 'Téléconsultation' && (
                                    <Button variant="outline-success" size="sm">
                                      Rejoindre
                                    </Button>
                                  )}
                                  {appointment.status === 'en attente' && (
                                    <Button variant="outline-danger" size="sm">
                                      Annuler
                                    </Button>
                                  )}
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </Table>

                      <h5 className="mb-3">Historique des rendez-vous</h5>
                      <Table responsive hover>
                        <thead className="bg-light">
                          <tr>
                            <th>Médecin</th>
                            <th>Spécialité</th>
                            <th>Date</th>
                            <th>Heure</th>
                            <th>Type</th>
                            <th>Statut</th>
                            <th>Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {appointmentHistory.map((appointment) => (
                            <tr key={appointment.id}>
                              <td>{appointment.doctor}</td>
                              <td>{appointment.specialty}</td>
                              <td>{appointment.date}</td>
                              <td>{appointment.time}</td>
                              <td>{appointment.type}</td>
                              <td>{getStatusBadge(appointment.status)}</td>
                              <td>
                                <Button variant="outline-primary" size="sm">
                                  Compte-rendu
                                </Button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </Table>
                    </Tab.Pane>

                    {/* Medical Records Tab */}
                    <Tab.Pane eventKey="medical-records">
                      <div className="d-flex justify-content-between align-items-center mb-4">
                        <h4 className="mb-0">Mon dossier médical</h4>
                        <div>
                          <Button variant="outline-success" className="me-2">
                            <FontAwesomeIcon icon={faDownload} className="me-2" />
                            Exporter
                          </Button>
                          <Button variant="primary">
                            <FontAwesomeIcon icon={faFileMedical} className="me-2" />
                            Ajouter un document
                          </Button>
                        </div>
                      </div>

                      <Form className="mb-4">
                        <InputGroup>
                          <Form.Control
                            placeholder="Rechercher dans mon dossier..."
                            aria-label="Rechercher"
                            aria-describedby="search-medical-records"
                          />
                          <Button variant="outline-secondary" id="search-medical-records">
                            <FontAwesomeIcon icon={faSearch} />
                          </Button>
                        </InputGroup>
                      </Form>

                      <Tab.Container id="medical-records-tabs" defaultActiveKey="summary">
                        <Nav variant="tabs" className="mb-3">
                          <Nav.Item>
                            <Nav.Link eventKey="summary">Résumé</Nav.Link>
                          </Nav.Item>
                          <Nav.Item>
                            <Nav.Link eventKey="consultations">Consultations</Nav.Link>
                          </Nav.Item>
                          <Nav.Item>
                            <Nav.Link eventKey="analysis">Analyses</Nav.Link>
                          </Nav.Item>
                          <Nav.Item>
                            <Nav.Link eventKey="imaging">Imagerie</Nav.Link>
                          </Nav.Item>
                          <Nav.Item>
                            <Nav.Link eventKey="treatments">Traitements</Nav.Link>
                          </Nav.Item>
                          <Nav.Item>
                            <Nav.Link eventKey="allergies">Allergies</Nav.Link>
                          </Nav.Item>
                        </Nav>

                        <Tab.Content>
                          <Tab.Pane eventKey="summary">
                            <Row>
                              <Col md={6}>
                                <Card className="mb-3">
                                  <Card.Header>Informations générales</Card.Header>
                                  <Card.Body>
                                    <p>
                                      <strong>Nom:</strong> {patient.name}
                                    </p>
                                    <p>
                                      <strong>Âge:</strong> {patient.age} ans
                                    </p>
                                    <p>
                                      <strong>Groupe sanguin:</strong> {patient.bloodType}
                                    </p>
                                    <p>
                                      <strong>Contact:</strong> {patient.phone}
                                    </p>
                                    <p>
                                      <strong>Email:</strong> {patient.email}
                                    </p>
                                    <p>
                                      <strong>Adresse:</strong> {patient.address}
                                    </p>
                                  </Card.Body>
                                </Card>
                              </Col>
                              <Col md={6}>
                                <Card className="mb-3">
                                  <Card.Header>Antécédents médicaux</Card.Header>
                                  <Card.Body>
                                    <p>Aucun antécédent médical significatif</p>
                                  </Card.Body>
                                </Card>
                              </Col>
                              <Col md={6}>
                                <Card className="mb-3">
                                  <Card.Header>Allergies</Card.Header>
                                  <Card.Body>
                                    <p>Aucune allergie connue</p>
                                  </Card.Body>
                                </Card>
                              </Col>
                              <Col md={6}>
                                <Card className="mb-3">
                                  <Card.Header>Médicaments actuels</Card.Header>
                                  <Card.Body>
                                    <ul>
                                      <li>Paracétamol 1000mg - 3x par jour</li>
                                      <li>Amoxicilline 500mg - 2x par jour</li>
                                    </ul>
                                  </Card.Body>
                                </Card>
                              </Col>
                            </Row>
                          </Tab.Pane>

                          <Tab.Pane eventKey="consultations">
                            <Table responsive hover>
                              <thead className="bg-light">
                                <tr>
                                  <th>Date</th>
                                  <th>Médecin</th>
                                  <th>Spécialité</th>
                                  <th>Motif</th>
                                  <th>Diagnostic</th>
                                  <th>Actions</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <td>10 Avril 2025</td>
                                  <td>Dr. Aissata Sy</td>
                                  <td>Cardiologie</td>
                                  <td>Douleurs thoraciques</td>
                                  <td>Hypertension artérielle</td>
                                  <td>
                                    <Button variant="outline-primary" size="sm">
                                      Voir
                                    </Button>
                                  </td>
                                </tr>
                                <tr>
                                  <td>25 Mars 2025</td>
                                  <td>Dr. Ndeye Daba Seck</td>
                                  <td>Dermatologie</td>
                                  <td>Éruption cutanée</td>
                                  <td>Dermatite de contact</td>
                                  <td>
                                    <Button variant="outline-primary" size="sm">
                                      Voir
                                    </Button>
                                  </td>
                                </tr>
                              </tbody>
                            </Table>
                          </Tab.Pane>

                          <Tab.Pane eventKey="analysis">
                            <Table responsive hover>
                              <thead className="bg-light">
                                <tr>
                                  <th>Date</th>
                                  <th>Type</th>
                                  <th>Laboratoire</th>
                                  <th>Résultat</th>
                                  <th>Actions</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <td>15 Avril 2025</td>
                                  <td>Bilan sanguin</td>
                                  <td>Laboratoire Pasteur</td>
                                  <td>Normal</td>
                                  <td>
                                    <Button variant="outline-primary" size="sm">
                                      Voir
                                    </Button>
                                  </td>
                                </tr>
                                <tr>
                                  <td>20 Mars 2025</td>
                                  <td>Analyse d'urine</td>
                                  <td>Laboratoire Central</td>
                                  <td>Normal</td>
                                  <td>
                                    <Button variant="outline-primary" size="sm">
                                      Voir
                                    </Button>
                                  </td>
                                </tr>
                              </tbody>
                            </Table>
                          </Tab.Pane>

                          <Tab.Pane eventKey="imaging">
                            <div className="d-flex justify-content-between align-items-center mb-3">
                              <h5 className="mb-0">Mes images médicales</h5>
                              <Button variant="primary">
                                <FontAwesomeIcon icon={faFileMedical} className="me-2" />
                                Importer des images DICOM
                              </Button>
                            </div>

                            <Row>
                              <Col md={4} className="mb-3">
                                <Card>
                                  <Card.Img variant="top" src="/images/x-ray-placeholder.jpg" />
                                  <Card.Body>
                                    <Card.Title>Radiographie thoracique</Card.Title>
                                    <Card.Text>
                                      <small className="text-muted">05 Avril 2025 - Dr. Aissata Sy</small>
                                    </Card.Text>
                                    <div className="d-flex justify-content-between">
                                      <Button variant="primary" size="sm">
                                        Visualiser
                                      </Button>
                                      <Button variant="outline-secondary" size="sm">
                                        Télécharger
                                      </Button>
                                    </div>
                                  </Card.Body>
                                </Card>
                              </Col>
                              <Col md={4} className="mb-3">
                                <Card>
                                  <Card.Img variant="top" src="/images/mri-placeholder.jpg" />
                                  <Card.Body>
                                    <Card.Title>IRM cérébrale</Card.Title>
                                    <Card.Text>
                                      <small className="text-muted">15 Mars 2025 - Dr. Ndeye Ndella Diop</small>
                                    </Card.Text>
                                    <div className="d-flex justify-content-between">
                                      <Button variant="primary" size="sm">
                                        Visualiser
                                      </Button>
                                      <Button variant="outline-secondary" size="sm">
                                        Télécharger
                                      </Button>
                                    </div>
                                  </Card.Body>
                                </Card>
                              </Col>
                              <Col md={4} className="mb-3">
                                <Card className="h-100 border-dashed border-2 bg-light">
                                  <Card.Body className="d-flex flex-column justify-content-center align-items-center text-center">
                                    <FontAwesomeIcon icon={faFileMedical} size="3x" className="text-muted mb-3" />
                                    <h5>Importer des images DICOM</h5>
                                    <p className="text-muted mb-3">Utilisez Orthanc pour visualiser et partager vos images médicales</p>
                                    <Button variant="outline-primary">Importer</Button>
                                  </Card.Body>
                                </Card>
                              </Col>
                            </Row>
                          </Tab.Pane>

                          <Tab.Pane eventKey="treatments">
                            <Table responsive hover>
                              <thead className="bg-light">
                                <tr>
                                  <th>Date début</th>
                                  <th>Date fin</th>
                                  <th>Médicament</th>
                                  <th>Posologie</th>
                                  <th>Prescrit par</th>
                                  <th>Statut</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <td>10 Avril 2025</td>
                                  <td>15 Avril 2025</td>
                                  <td>Paracétamol 1000mg</td>
                                  <td>3x par jour</td>
                                  <td>Dr. Aissata Sy</td>
                                  <td>{getStatusBadge('actif')}</td>
                                </tr>
                                <tr>
                                  <td>10 Avril 2025</td>
                                  <td>17 Avril 2025</td>
                                  <td>Amoxicilline 500mg</td>
                                  <td>2x par jour</td>
                                  <td>Dr. Aissata Sy</td>
                                  <td>{getStatusBadge('actif')}</td>
                                </tr>
                                <tr>
                                  <td>25 Mars 2025</td>
                                  <td>10 Avril 2025</td>
                                  <td>Loratadine 10mg</td>
                                  <td>1x par jour</td>
                                  <td>Dr. Ndeye Daba Seck</td>
                                  <td>{getStatusBadge('expiré')}</td>
                                </tr>
                              </tbody>
                            </Table>
                          </Tab.Pane>

                          <Tab.Pane eventKey="allergies">
                            <Card>
                              <Card.Body>
                                <h5 className="mb-3">Aucune allergie connue</h5>
                                <p>Aucune allergie n'a été enregistrée dans votre dossier médical.</p>
                                <Button variant="outline-primary">
                                  <FontAwesomeIcon icon={faFileMedical} className="me-2" />
                                  Ajouter une allergie
                                </Button>
                              </Card.Body>
                            </Card>
                          </Tab.Pane>
                        </Tab.Content>
                      </Tab.Container>
                    </Tab.Pane>

                    {/* Prescriptions Tab */}
                    <Tab.Pane eventKey="prescriptions">
                      <div className="d-flex justify-content-between align-items-center mb-4">
                        <h4 className="mb-0">Mes ordonnances</h4>
                        <div>
                          <Button variant="outline-success" className="me-2">
                            <FontAwesomeIcon icon={faDownload} className="me-2" />
                            Exporter
                          </Button>
                        </div>
                      </div>

                      <Nav variant="tabs" className="mb-3">
                        <Nav.Item>
                          <Nav.Link active>Actives</Nav.Link>
                        </Nav.Item>
                        <Nav.Item>
                          <Nav.Link>Toutes</Nav.Link>
                        </Nav.Item>
                      </Nav>

                      {prescriptions
                        .filter((p) => p.status === 'actif')
                        .map((prescription) => (
                          <Card key={prescription.id} className="mb-3">
                            <Card.Header className="bg-light d-flex justify-content-between align-items-center">
                              <span>
                                <strong>Ordonnance #{prescription.id}</strong> - {prescription.date}
                              </span>
                              {getStatusBadge(prescription.status)}
                            </Card.Header>
                            <Card.Body>
                              <p>
                                <strong>Médecin:</strong> {prescription.doctor}
                              </p>
                              <h6>Médicaments:</h6>
                              <Table responsive bordered hover size="sm" className="mb-0">
                                <thead className="bg-light">
                                  <tr>
                                    <th>Médicament</th>
                                    <th>Dosage</th>
                                    <th>Fréquence</th>
                                    <th>Durée</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {prescription.medications.map((med, index) => (
                                    <tr key={index}>
                                      <td>{med.name}</td>
                                      <td>{med.dosage}</td>
                                      <td>{med.frequency}</td>
                                      <td>{med.duration}</td>
                                    </tr>
                                  ))}
                                </tbody>
                              </Table>
                            </Card.Body>
                            <Card.Footer className="bg-white">
                              <div className="d-flex gap-2">
                                <Button variant="primary" size="sm">
                                  <FontAwesomeIcon icon={faDownload} className="me-2" />
                                  Télécharger PDF
                                </Button>
                                <Button variant="outline-primary" size="sm">
                                  Envoyer par email
                                </Button>
                              </div>
                            </Card.Footer>
                          </Card>
                        ))}
                    </Tab.Pane>

                    {/* Teleconsultation Tab */}
                    <Tab.Pane eventKey="teleconsultation">
                      <div className="d-flex justify-content-between align-items-center mb-4">
                        <h4 className="mb-0">Téléconsultation</h4>
                        <Button variant="primary">
                          <FontAwesomeIcon icon={faCalendarCheck} className="me-2" />
                          Planifier une téléconsultation
                        </Button>
                      </div>

                      <Row>
                        <Col md={6} className="mb-4">
                          <Card className="h-100">
                            <Card.Body>
                              <h5 className="mb-3">Prochaine téléconsultation</h5>
                              {upcomingAppointments.find((a) => a.type === 'Téléconsultation' && a.status === 'confirmé') ? (
                                <>
                                  <div className="d-flex align-items-center mb-3">
                                    <div className="bg-primary text-white rounded-circle p-3 me-3">
                                      <FontAwesomeIcon icon={faUserMd} size="2x" />
                                    </div>
                                    <div>
                                      <h6 className="mb-0">Dr. Aissata Sy</h6>
                                      <p className="text-muted mb-0">Cardiologie</p>
                                    </div>
                                  </div>
                                  <p>
                                    <strong>Date:</strong> 10 Mai 2025
                                  </p>
                                  <p>
                                    <strong>Heure:</strong> 14:30
                                  </p>
                                  <div className="d-grid gap-2">
                                    <Button variant="success">
                                      <FontAwesomeIcon icon={faVideo} className="me-2" />
                                      Rejoindre la téléconsultation
                                    </Button>
                                    <Button variant="outline-danger">Annuler</Button>
                                  </div>
                                </>
                              ) : (
                                <div className="text-center py-4">
                                  <FontAwesomeIcon icon={faCalendarCheck} size="3x" className="text-muted mb-3" />
                                  <h5>Aucune téléconsultation planifiée</h5>
                                  <p className="text-muted mb-3">Vous n'avez pas de téléconsultation programmée</p>
                                  <Button variant="primary">Planifier maintenant</Button>
                                </div>
                              )}
                            </Card.Body>
                          </Card>
                        </Col>
                        <Col md={6} className="mb-4">
                          <Card className="h-100">
                            <Card.Body>
                              <h5 className="mb-3">Comment ça marche ?</h5>
                              <ol className="ps-3">
                                <li className="mb-2">Planifiez une téléconsultation avec un médecin disponible</li>
                                <li className="mb-2">Préparez votre espace et vérifiez votre connexion internet</li>
                                <li className="mb-2">
                                  Rejoignez la téléconsultation à l'heure prévue en cliquant sur le bouton "Rejoindre"
                                </li>
                                <li className="mb-2">Consultez votre médecin par vidéoconférence sécurisée</li>
                                <li>Recevez votre ordonnance électronique directement sur la plateforme</li>
                              </ol>
                              <div className="d-grid gap-2 mt-3">
                                <Button variant="outline-primary">Voir le tutoriel vidéo</Button>
                              </div>
                            </Card.Body>
                          </Card>
                        </Col>
                      </Row>

                      <Card>
                        <Card.Header>Historique des téléconsultations</Card.Header>
                        <Card.Body>
                          <Table responsive hover>
                            <thead className="bg-light">
                              <tr>
                                <th>Date</th>
                                <th>Médecin</th>
                                <th>Spécialité</th>
                                <th>Durée</th>
                                <th>Actions</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td>25 Avril 2025</td>
                                <td>Dr. Ndeye Daba Seck</td>
                                <td>Dermatologie</td>
                                <td>15 min</td>
                                <td>
                                  <Button variant="outline-primary" size="sm">
                                    Compte-rendu
                                  </Button>
                                </td>
                              </tr>
                            </tbody>
                          </Table>
                        </Card.Body>
                      </Card>
                    </Tab.Pane>

                    {/* Messages Tab */}
                    <Tab.Pane eventKey="messages">
                      <div className="d-flex justify-content-between align-items-center mb-4">
                        <h4 className="mb-0">Messages</h4>
                        <Button variant="primary">
                          <FontAwesomeIcon icon={faComments} className="me-2" />
                          Nouveau message
                        </Button>
                      </div>

                      <Row>
                        <Col md={4}>
                          <Card className="mb-3 mb-md-0">
                            <Card.Header className="bg-light">Conversations</Card.Header>
                            <div className="message-list">
                              <div className="message-item active p-3 border-bottom">
                                <div className="d-flex align-items-center">
                                  <div className="me-2 position-relative">
                                    <img
                                      src="/images/doctor-avatar1.jpg"
                                      alt="Dr. Aissata Sy"
                                      className="avatar-sm rounded-circle"
                                    />
                                    <span className="status-indicator online"></span>
                                  </div>
                                  <div className="flex-grow-1">
                                    <h6 className="mb-0">Dr. Aissata Sy</h6>
                                    <p className="text-muted mb-0 text-truncate small">
                                      Bonjour, comment vous sentez-vous...
                                    </p>
                                  </div>
                                  <div className="text-end">
                                    <small className="text-muted">09:32</small>
                                    <Badge bg="primary" pill className="ms-2">
                                      2
                                    </Badge>
                                  </div>
                                </div>
                              </div>
                              <div className="message-item p-3 border-bottom">
                                <div className="d-flex align-items-center">
                                  <div className="me-2 position-relative">
                                    <img
                                      src="/images/doctor-avatar2.jpg"
                                      alt="Dr. Ndeye Daba Seck"
                                      className="avatar-sm rounded-circle"
                                    />
                                    <span className="status-indicator offline"></span>
                                  </div>
                                  <div className="flex-grow-1">
                                    <h6 className="mb-0">Dr. Ndeye Daba Seck</h6>
                                    <p className="text-muted mb-0 text-truncate small">
                                      Votre peau s'améliore bien...
                                    </p>
                                  </div>
                                  <div className="text-end">
                                    <small className="text-muted">Hier</small>
                                  </div>
                                </div>
                              </div>
                              <div className="message-item p-3 border-bottom">
                                <div className="d-flex align-items-center">
                                  <div className="me-2 position-relative">
                                    <img
                                      src="/images/doctor-avatar3.jpg"
                                      alt="Dr. Ndeye Ndella Diop"
                                      className="avatar-sm rounded-circle"
                                    />
                                    <span className="status-indicator away"></span>
                                  </div>
                                  <div className="flex-grow-1">
                                    <h6 className="mb-0">Dr. Ndeye Ndella Diop</h6>
                                    <p className="text-muted mb-0 text-truncate small">
                                      N'oubliez pas votre rendez-vous...
                                    </p>
                                  </div>
                                  <div className="text-end">
                                    <small className="text-muted">27/04</small>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </Card>
                        </Col>
                        <Col md={8}>
                          <Card>
                            <Card.Header className="bg-light d-flex justify-content-between align-items-center">
                              <div className="d-flex align-items-center">
                                <img
                                  src="/images/doctor-avatar1.jpg"
                                  alt="Dr. Aissata Sy"
                                  className="avatar-sm rounded-circle me-2"
                                />
                                <div>
                                  <h6 className="mb-0">Dr. Aissata Sy</h6>
                                  <small className="text-muted">Cardiologie</small>
                                </div>
                              </div>
                              <div>
                                <Button variant="outline-primary" size="sm" className="me-2">
                                  <FontAwesomeIcon icon={faVideo} className="me-1" />
                                  Appel vidéo
                                </Button>
                                <Button variant="outline-secondary" size="sm">
                                  <FontAwesomeIcon icon={faPhone} className="me-1" />
                                  Appel
                                </Button>
                              </div>
                            </Card.Header>
                            <div className="chat-messages p-3">
                              <div className="message-date-divider d-flex align-items-center my-3">
                                <div className="line flex-grow-1"></div>
                                <div className="mx-2 text-muted small">Aujourd'hui</div>
                                <div className="line flex-grow-1"></div>
                              </div>
                              <div className="message received mb-3">
                                <div className="message-content p-3 bg-light rounded">
                                  Bonjour Mme Diop, comment vous sentez-vous depuis notre dernière consultation ?
                                </div>
                                <div className="message-time text-muted small mt-1">09:30</div>
                              </div>
                              <div className="message received mb-3">
                                <div className="message-content p-3 bg-light rounded">
                                  Avez-vous pris votre tension régulièrement comme je vous l'ai recommandé ?
                                </div>
                                <div className="message-time text-muted small mt-1">09:31</div>
                              </div>
                              <div className="message sent mb-3 text-end">
                                <div className="message-content p-3 bg-primary text-white rounded ms-auto">
                                  Bonjour Docteur, je me sens beaucoup mieux. J'ai pris ma tension tous les jours.
                                </div>
                                <div className="message-time text-muted small mt-1">09:45</div>
                              </div>
                            </div>
                            <Card.Footer className="bg-white p-3">
                              <InputGroup>
                                <Form.Control placeholder="Écrivez votre message..." aria-label="Message" />
                                <Button variant="primary">Envoyer</Button>
                              </InputGroup>
                            </Card.Footer>
                          </Card>
                        </Col>
                      </Row>
                    </Tab.Pane>

                    {/* Health Tracking Tab */}
                    <Tab.Pane eventKey="health-tracking">
                      <div className="d-flex justify-content-between align-items-center mb-4">
                        <h4 className="mb-0">Suivi de santé</h4>
                        <Button variant="primary">
                          <FontAwesomeIcon icon={faFileMedical} className="me-2" />
                          Ajouter des données
                        </Button>
                      </div>

                      <Row>
                        <Col md={6} className="mb-4">
                          <Card>
                            <Card.Header className="bg-light">Tension artérielle</Card.Header>
                            <Card.Body>
                              <LineChart
                                width={500}
                                height={300}
                                data={bloodPressureData}
                                margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                              >
                                <XAxis dataKey="date" />
                                <YAxis />
                                <Tooltip />
                                <Legend />
                                <Line type="monotone" dataKey="systolic" stroke="#8884d8" />
                                <Line type="monotone" dataKey="diastolic" stroke="#82ca9d" />
                              </LineChart>
                            </Card.Body>
                          </Card>
                        </Col>
                        <Col md={6} className="mb-4">
                          <Card>
                            <Card.Header className="bg-light">Poids</Card.Header>
                            <Card.Body>
                              <BarChart
                                width={500}
                                height={300}
                                data={weightData}
                                margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                              >
                                <XAxis dataKey="date" />
                                <YAxis />
                                <Tooltip />
                                <Legend />
                                <Bar dataKey="weight" fill="#8884d8" />
                              </BarChart>
                            </Card.Body>
                          </Card>
                        </Col>
                        <Col md={6} className="mb-4">
                          <Card>
                            <Card.Header className="bg-light">Fréquence cardiaque</Card.Header>
                            <Card.Body>
                              <AreaChart
                                width={500}
                                height={300}
                                data={heartRateData}
                                margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                              >
                                <XAxis dataKey="date" />
                                <YAxis />
                                <Tooltip />
                                <Legend />
                                <Area type="monotone" dataKey="heartRate" stroke="#8884d8" fill="#8884d8" />
                              </AreaChart>
                            </Card.Body>
                          </Card>
                        </Col>
                        <Col md={6} className="mb-4">
                          <Card>
                            <Card.Header className="bg-light">Suivi de la glycémie</Card.Header>
                            <Card.Body>
                              <RadarChart cx={250} cy={200} outerRadius={150} width={500} height={400} data={bloodSugarData}>
                                <PolarGrid />
                                <PolarAngleAxis dataKey="date" />
                                <PolarRadiusAxis angle={30} domain={[0, 100]} />
                                <Radar
                                  name="Glycémie"
                                  dataKey="bloodSugar"
                                  stroke="#8884d8"
                                  fill="#8884d8"
                                  fillOpacity={0.6}
                                />
                              </RadarChart>
                            </Card.Body>
                          </Card>
                        </Col>
                      </Row>
                      <Card>
                        <Card.Header>Historique des mesures</Card.Header>
                        <Card.Body>
                          <Table responsive hover>
                            <thead className="bg-light">
                              <tr>
                                <th>Date</th>
                                <th>Tension artérielle</th>
                                <th>Poids</th>
                                <th>Fréquence cardiaque</th>
                                <th>Glycémie</th>
                              </tr>
                            </thead>
                            <tbody>
                              {healthData.map((data, index) => (
                                <tr key={index}>
                                  <td>{data.date}</td>
                                  <td>
                                    {data.bloodPressure.systolic}/{data.bloodPressure.diastolic} mmHg
                                  </td>
                                  <td>{data.weight} kg</td>
                                  <td>{data.heartRate} bpm</td>
                                  <td>{data.bloodSugar} mg/dL</td>
                                </tr>
                              ))}
                            </tbody>
                          </Table>
                        </Card.Body>
                      </Card>
                    </Tab.Pane>
                  </Tab.Content>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Tab.Container>
      </Container>
    </div>
  );
}

export default PatientDashboard;