import React, { useState } from 'react';
import { Calendar, Check, Clock, Users, Video, Hospital, X } from 'lucide-react';

// Composant de formulaire de prise de rendez-vous
const AppointmentForm = () => {
  // États pour stocker les valeurs du formulaire
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    doctor: '',
    specialty: '',
    date: '',
    time: '',
    type: 'Présentiel',
    reason: '',
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  // Liste des médecins (normalement chargée depuis une API)
  const doctors = [
    { id: 1, name: 'Dr. Aissata Sy', specialty: 'Cardiologie' },
    { id: 2, name: 'Dr. Ndeye Daba Seck', specialty: 'Dermatologie' },
    { id: 3, name: 'Dr. Ndeye Ndella Diop', specialty: 'Médecine Générale' },
  ];

  // Liste des spécialités disponibles
  const specialties = ['Cardiologie', 'Dermatologie', 'Médecine Générale', 'Pédiatrie', 'Ophtalmologie'];

  // Gérer les changements dans les champs du formulaire
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });

    // Si l'utilisateur choisit un médecin, mettre à jour automatiquement la spécialité
    if (name === 'doctor') {
      const selectedDoctor = doctors.find((doc) => doc.name === value);
      if (selectedDoctor) {
        setFormData((prev) => ({
          ...prev,
          specialty: selectedDoctor.specialty,
        }));
      }
    }

    // Effacer l'erreur pour ce champ
    if (errors[name]) {
      setErrors(prev => ({...prev, [name]: undefined}));
    }
  };

  // Valider le formulaire
  const validateForm = () => {
    const newErrors = {};
    if (!formData.doctor) newErrors.doctor = "Veuillez choisir un médecin";
    if (!formData.specialty) newErrors.specialty = "Veuillez choisir une spécialité";
    if (!formData.date) newErrors.date = "Veuillez choisir une date";
    if (!formData.time) newErrors.time = "Veuillez choisir un horaire";
    if (!formData.reason) newErrors.reason = "Veuillez indiquer le motif de votre consultation";
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Gérer la soumission du formulaire
  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    // Simuler l'ajout d'un rendez-vous
    console.log("Nouveau rendez-vous:", {
      id: `RDV${Math.floor(Math.random() * 1000)}`,
      doctor: formData.doctor,
      specialty: formData.specialty,
      date: formData.date,
      time: formData.time,
      type: formData.type,
      status: 'en attente',
      reason: formData.reason,
    });
    
    setSubmitted(true);
    
    // Dans un cas réel, nous enverrions les données au backend
    setTimeout(() => {
      setShowModal(false);
      // Réinitialiser après fermeture
      setTimeout(() => {
        setFormData({
          doctor: '',
          specialty: '',
          date: '',
          time: '',
          type: 'Présentiel',
          reason: '',
        });
        setSubmitted(false);
      }, 300);
    }, 1500);
  };

  // Générer les dates disponibles (à partir de demain jusqu'à 30 jours plus tard)
  const generateAvailableDates = () => {
    const dates = [];
    const today = new Date();
    
    for (let i = 1; i <= 30; i++) {
      const date = new Date();
      date.setDate(today.getDate() + i);
      
      // Exclure les weekends
      if (date.getDay() !== 0 && date.getDay() !== 6) {
        const formattedDate = date.toISOString().split('T')[0];
        const displayDate = date.toLocaleDateString('fr-FR', {
          day: 'numeric',
          month: 'long',
          year: 'numeric',
        });
        dates.push({ value: formattedDate, display: displayDate });
      }
    }
    
    return dates;
  };

  // Générer des créneaux horaires (de 8h à 18h par intervalle de 30min)
  const generateTimeSlots = () => {
    const slots = [];
    for (let hour = 8; hour < 18; hour++) {
      slots.push(`${hour.toString().padStart(2, '0')}:00`);
      slots.push(`${hour.toString().padStart(2, '0')}:30`);
    }
    return slots;
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      {/* Bouton pour ouvrir le modal */}
      <button 
        onClick={() => setShowModal(true)}
        className="flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-md font-medium hover:bg-blue-700"
      >
        <Calendar className="w-5 h-5 mr-2" />
        Prendre un Rendez-vous
      </button>

      {/* Modal de prise de rendez-vous */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-auto">
            {/* En-tête du modal */}
            <div className="bg-blue-600 text-white px-6 py-4 flex justify-between items-center rounded-t-lg">
              <h3 className="text-xl font-semibold flex items-center">
                <Calendar className="w-5 h-5 mr-2" />
                Prendre un rendez-vous
              </h3>
              <button onClick={() => setShowModal(false)} className="text-white hover:text-gray-200">
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Corps du modal - Formulaire */}
            <div className="p-6">
              {submitted ? (
                <div className="text-center py-10">
                  <div className="bg-green-100 text-green-700 p-4 rounded-lg mb-6 flex items-center justify-center">
                    <Check className="w-6 h-6 mr-2" />
                    <span className="font-medium">Votre rendez-vous a été enregistré avec succès!</span>
                  </div>
                  <p className="text-gray-600">
                    Un email de confirmation vous sera envoyé avec tous les détails.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Médecin et Spécialité */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Médecin
                      </label>
                      <select
                        name="doctor"
                        value={formData.doctor}
                        onChange={handleChange}
                        className={`w-full px-3 py-2 border ${errors.doctor ? 'border-red-500' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500`}
                      >
                        <option value="">Choisir un médecin</option>
                        {doctors.map((doctor) => (
                          <option key={doctor.id} value={doctor.name}>
                            {doctor.name} ({doctor.specialty})
                          </option>
                        ))}
                      </select>
                      {errors.doctor && <p className="mt-1 text-sm text-red-600">{errors.doctor}</p>}
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Spécialité
                      </label>
                      <select
                        name="specialty"
                        value={formData.specialty}
                        onChange={handleChange}
                        disabled={formData.doctor !== ''}
                        className={`w-full px-3 py-2 border ${errors.specialty ? 'border-red-500' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 ${formData.doctor !== '' ? 'bg-gray-100' : ''}`}
                      >
                        <option value="">Choisir une spécialité</option>
                        {specialties.map((specialty) => (
                          <option key={specialty} value={specialty}>
                            {specialty}
                          </option>
                        ))}
                      </select>
                      {errors.specialty && <p className="mt-1 text-sm text-red-600">{errors.specialty}</p>}
                    </div>
                  </div>

                  {/* Date et Heure */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Date
                      </label>
                      <select
                        name="date"
                        value={formData.date}
                        onChange={handleChange}
                        className={`w-full px-3 py-2 border ${errors.date ? 'border-red-500' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500`}
                      >
                        <option value="">Choisir une date</option>
                        {generateAvailableDates().map((date) => (
                          <option key={date.value} value={date.value}>
                            {date.display}
                          </option>
                        ))}
                      </select>
                      {errors.date && <p className="mt-1 text-sm text-red-600">{errors.date}</p>}
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Heure
                      </label>
                      <select
                        name="time"
                        value={formData.time}
                        onChange={handleChange}
                        className={`w-full px-3 py-2 border ${errors.time ? 'border-red-500' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500`}
                      >
                        <option value="">Choisir un horaire</option>
                        {generateTimeSlots().map((time) => (
                          <option key={time} value={time}>
                            {time}
                          </option>
                        ))}
                      </select>
                      {errors.time && <p className="mt-1 text-sm text-red-600">{errors.time}</p>}
                    </div>
                  </div>

                  {/* Type de consultation */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Type de consultation
                    </label>
                    <div className="grid grid-cols-2 gap-4">
                      <button
                        type="button"
                        onClick={() => setFormData({...formData, type: 'Présentiel'})}
                        className={`flex items-center justify-center px-4 py-3 border rounded-md ${
                          formData.type === 'Présentiel' 
                            ? 'bg-blue-600 text-white border-blue-600' 
                            : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
                        }`}
                      >
                        <Hospital className="w-5 h-5 mr-2" />
                        Présentiel
                      </button>
                      <button
                        type="button"
                        onClick={() => setFormData({...formData, type: 'Téléconsultation'})}
                        className={`flex items-center justify-center px-4 py-3 border rounded-md ${
                          formData.type === 'Téléconsultation' 
                            ? 'bg-blue-600 text-white border-blue-600' 
                            : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
                        }`}
                      >
                        <Video className="w-5 h-5 mr-2" />
                        Téléconsultation
                      </button>
                    </div>
                  </div>

                  {/* Motif de consultation */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Motif de consultation
                    </label>
                    <textarea
                      name="reason"
                      value={formData.reason}
                      onChange={handleChange}
                      rows={3}
                      placeholder="Décrivez brièvement le motif de votre consultation..."
                      className={`w-full px-3 py-2 border ${errors.reason ? 'border-red-500' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500`}
                    ></textarea>
                    {errors.reason && <p className="mt-1 text-sm text-red-600">{errors.reason}</p>}
                  </div>

                  {/* Boutons d'action */}
                  <div className="flex justify-between pt-4">
                    <button
                      type="button"
                      onClick={() => setShowModal(false)}
                      className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50"
                    >
                      Annuler
                    </button>
                    <button
                      type="submit"
                      className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                    >
                      <Check className="w-5 h-5 mr-2" />
                      Confirmer le rendez-vous
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AppointmentForm;